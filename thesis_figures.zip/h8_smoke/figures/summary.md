Error = `err_solver_kcal` (kcal/mol), mean ± std over seeds.

Oracle / CIPSI = best possible / classical selection with the SAME number of determinants (DMET route only).

| molecule | R | method | shots | n | error | oracle | CIPSI | w1 | subspace | qubits | wall (s) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| H8 | – | DMET+SQD | 1000 | 3 | +17.570 ± 1.599 | -0.000 | -0.000 | 0.868 | 0.597 | 16 | 7.4 |
| H8 | – | DMET+SQD | 10000 | 3 | +1.628 ± 2.767 | -0.000 | -0.000 | 0.868 | 0.963 | 16 | 7.8 |
| H8 | – | DMET+SKQD | 1000 | 3 | +1.787 ± 0.238 | 0.024 | 0.025 | 0.868 | 0.332 | 16 | 1468.3 |
| H8 | – | DMET+SKQD | 10000 | 3 | +0.999 ± 0.335 | 0.001 | 0.001 | 0.868 | 0.458 | 16 | 1471.0 |
| H8 | – | DMET+GQE | – | 3 | +0.072 ± 0.040 | 0.005 | 0.005 | 0.868 | 0.394 | 16 | 858.3 |
| H8 | – | LASSCF | – | 1 | – | – | – | – | – | – | 44.6 |
| H8 | – | LASSQD (no opt) | 1000 | 3 | +42.544 ± 10.784 | – | – | – | 0.250 | 16 | 31.2 |
| H8 | – | LASSQD (no opt) | 10000 | 3 | +7.417 ± 6.954 | – | – | – | 0.500 | 16 | 47.6 |
| H8 | – | LASSQD (opt) | 1000 | 3 | +0.000 ± 0.000 | – | – | – | 1.000 | 16 | 56.6 |
| H8 | – | LASSQD (opt) | 10000 | 3 | +0.000 ± 0.000 | – | – | – | 1.000 | 16 | 58.3 |
